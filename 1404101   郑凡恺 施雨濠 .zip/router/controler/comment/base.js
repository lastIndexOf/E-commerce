module.exports = class {
  
}
