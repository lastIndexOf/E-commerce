module.exports = class {
  static test() {
    return 'hello, world'
  }
}