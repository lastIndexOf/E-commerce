const send = require('koa-send')

module.exports = {
  send
}