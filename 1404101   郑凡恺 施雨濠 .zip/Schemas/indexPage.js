const
	mongoose  =  require('mongoose'),
	Schema    =  mongoose.Schema


let indexPageSchema = new Schema({
  
})


indexPageSchema.methods = {}
indexPageSchema.statics = {}

module.exports = indexPageSchema
